self.on('message', function(message) {
    $('#annotation').html(message);
});