self.on('message', function(message) {
//    $('#annotation').html(message);
//    $('html').html(message);
    window.location.replace(message)
//    location.reload();
});