self.on("message", function onMessage(scriptRules) {
    var scriptArr = JSON.parse(scriptRules);
    
    $( "#curr_active_name" ).text(scriptArr.last.name);
    $( "#curr_active_descr" ).text(scriptArr.description);
});