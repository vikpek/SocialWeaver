var annotationAnchor;

$('#commentbox').button().click(function( event ) {    
    self.postMessage('http://didits.org:8080/erpfuture2013/');
});

$('#wiki').button().click(function( event ) {
    self.postMessage('http://en.wikipedia.org/wiki/Enterprise_resource_planning');
});

$('#custom').button().click(function( event ) {
    var textArea = document.getElementById('custom-html-box');
    self.postMessage(textArea.value);
});

self.on('message', function() {
  var textArea = document.getElementById('annotation-box');
  textArea.value = '';
  textArea.focus();
});