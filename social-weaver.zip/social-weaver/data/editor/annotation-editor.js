//var textArea = document.getElementById('annotation-box');
// 
//textArea.onkeyup = function(event) {
//  if (event.keyCode == 13) {
//    self.postMessage(textArea.value);
//    textArea.value = '';
//  }
//};
var annotationAnchor;

$('#commentbox').button().click(function( event ) {
    
    self.postMessage('<script type="text/javascript" async>if(window.location.href.indexOf(\'&routeignore=1\') == -1){(function(){document.write(\'<div id="fcs_div"><a title="free comment script" href="http://www.freecommentscript.com">&nbsp;&nbsp;<b>Free HTML User Comments</b></a></div>\');fcsfcs=document.createElement(\'script\');fcsfcs.type="text/javascript";fcsfcs.src="http://www.freecommentscript.com/GetComments.php?p=5204bda13c052&s=" + escape(window.location) + "&Width=630&FontColor=111111&BackgroundColor=FFFFFF&FontSize=16&Size=10";setTimeout("document.getElementById(\'fcs_div\').appendChild(fcsfcs)",1);})();}</script><noscript><div><a href="http://www.freecommentscript.com" title="free html user comment box">Free Comment Script</a></div></noscript>');
});

$('#wiki').button().click(function( event ) {
    self.postMessage('Wiki Placeholder');
});

$('#custom').button().click(function( event ) {
    self.postMessage('<html><title>Hello</title><body>World</body></html>');
});

self.on('message', function() {
  var textArea = document.getElementById('annotation-box');
  textArea.value = '';
  textArea.focus();
});