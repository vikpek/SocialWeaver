var scriptRules = null;

String.prototype.hashCode = function(){
    var hash = 0;
	if (this.length == 0) return hash;
	for (i = 0; i < this.length; i++) {
		char = this.charCodeAt(i);
		hash = ((hash<<5)-hash)+char;
		hash = hash & hash; // Convert to 32bit integer
	}
	return hash.toString();
}

self.on('message', function onMessage(arr) {

    console.log('arr0 '+ arr[0]);
    annotations = JSON.parse(arr[0]);
    scriptRules = arr[1];
    
    annotations.forEach(
        function(annotation) {
            if(annotation.url == document.location.toString()) {
                createAnchor(annotation);
            }
            
            var hashCode = annotation.payload.hashCode();
            
            $('#' + hashCode).css('border', 'solid 2px red');
        }
    );
    
    
    
    $('.annotated').css('border', 'solid 2px green');
    
    $('.annotated').bind('click', function(event) {
        self.port.emit('show', $(this).attr('annotation'));
        event.stopPropagation();
        event.preventDefault();
    });      
});
 
function createAnchor(annotation) {
    var payload = annotation.payload;
    var arr = JSON.parse(payload);
    
    var matched = new Boolean();
    matched = false;
    
    
    var rules = null;
    if(typeof(scriptRules) == 'undefined'){
        console.error('Undefinded script rules');    
    }else{
        var rArr = JSON.parse(scriptRules);
        rules = rArr.rules;
    }
    
    // TODO triple-for - ugly ........... 
    var matchedElement = null;
    $("*").each(
        function(indx, curEl){
            matchedElement = $(this);
            var noRuleFailure = new Boolean(true);  
            
            var curCmdEval = null;
            var payloadEval = null;
            arr.forEach(
                function(el){
                    for (var akey in el) {
                        if (el.hasOwnProperty(akey)) {
                                rules.forEach(
                                    function(rule){
                                        for (var rkey in rule) {
                                            if (rule.hasOwnProperty(rkey) && noRuleFailure) {
                                                if(rkey === akey){
                                                    curCmdEval = eval(rule[rkey]);
                                                    payloadEval = el[akey];
                                                    if(curCmdEval != payloadEval || !curCmdEval || !payloadEval){
                                                        noRuleFailure = false;
                                                        return false;
                                                    }
                                                }
                                            }
                                        }
                                });
                        }
                    }
            });

            if(noRuleFailure){
                console.log('Found match');
                matchedElement.addClass('annotated');
                matchedElement.attr("id", payload.hashCode());
                matchedElement.attr('annotation', arr[2].social_content);
                return true;
            }
    });
}